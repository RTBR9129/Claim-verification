
import json
from pathlib import Path
import random
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import accuracy_score, classification_report
from sklearn.metrics import confusion_matrix
from hybrid_retriever import HybridRetriever


PROJECT_DIR = Path(__file__).resolve().parent.parent
DATA_FILE = PROJECT_DIR / "data" / "clean_train.jsonl"

TOP_K = 3
MAX_CLAIMS = 1000


def load_jsonl(file_path):
    records = []

    with open(file_path, "r", encoding="utf-8") as file:
        for line in file:
            if line.strip():
                records.append(json.loads(line))

    return records


def retrieve_evidence(claims, retriever, description):
    combined_texts = []

    print(f"\nRetrieving evidence for {description} claims...")

    for i, claim in enumerate(claims):
        results = retriever.retrieve(claim, top_k=TOP_K)

        evidence = " ".join(
            item["text"] for item in results
        )

        combined_texts.append(
            "Claim: " + claim + " Evidence: " + evidence
        )

        if (i + 1) % 100 == 0:
            print(f"Processed {i + 1}/{len(claims)} claims")

    print(f"Completed {description} retrieval.")

    return combined_texts


def main():
    print("Loading claims...")
    records = load_jsonl(DATA_FILE)

    print("Total available claims:", len(records))

    if len(records) > MAX_CLAIMS:
        records, _ = train_test_split(
            records,
            train_size=MAX_CLAIMS,
            random_state=42,
            stratify=[item["label"] for item in records]
        )

    claims = [item["claim"] for item in records]
    labels = [item["label"] for item in records]

    print("Claims selected:", len(claims))

    print("\nSplitting training and testing data...")

    X_train_claims, X_test_claims, y_train, y_test = train_test_split(
        claims,
        labels,
        test_size=0.2,
        random_state=42,
        stratify=labels
    )

    print("Training claims:", len(X_train_claims))
    print("Testing claims:", len(X_test_claims))

    print("\nInitializing hybrid retriever...")
    retriever = HybridRetriever()

    print("\n" + "=" * 70)
    print("RETRIEVAL QUALITY INSPECTION")
    print("=" * 70)

    random.seed(42)

    selected_records = []

    for label in ["SUPPORTS", "REFUTES", "NOT ENOUGH INFO"]:
        class_records = [
            item for item in records if item["label"] == label
        ]

        selected_records.extend(
            random.sample(class_records, min(4, len(class_records)))
        )

    for i, record in enumerate(selected_records, start=1):
        claim = record["claim"]
        results = retriever.retrieve(claim, top_k=TOP_K)

        print("\n" + "=" * 70)
        print(f"CLAIM {i}")
        print("Actual label:", record["label"])
        print("Claim:", claim)

        for rank, result in enumerate(results, start=1):
            print(f"\nEvidence {rank}")
            print("Page:", result["title"])
            print("RRF score:", round(result["score"], 6))
            print("Text:", result["text"])

    print("\nInspection complete.")
    return


    X_train = retrieve_evidence(
        X_train_claims, retriever, "training"
    )

    X_test = retrieve_evidence(
        X_test_claims, retriever, "testing"
    )

    model = Pipeline([
        ("tfidf", TfidfVectorizer(
            stop_words="english",
            ngram_range=(1, 2),
            max_features=100000,
            min_df=2
        )),
        ("classifier", LogisticRegression(
            max_iter=1000,
            class_weight="balanced"
        ))
    ])

    print("\nTraining evidence-grounded classifier...")
    model.fit(X_train, y_train)

    print("\nEvaluating classifier...")
    predictions = model.predict(X_test)

    print("\nEvidence-grounded evaluation")
    print("-" * 40)

    print(
        "Accuracy:",
        round(accuracy_score(y_test, predictions), 4)
    )

    print(
        classification_report(
            y_test,
            predictions,
            zero_division=0
        )
    )

    print("\nConfusion Matrix")
    print("Labels:", model.classes_)
    print(confusion_matrix(y_test, predictions, labels=model.classes_))

    print("\nPredicted label counts:")
    from collections import Counter
    print(Counter(predictions))


    print("\n" + "=" * 45)
    print("CLAIM-ONLY BASELINE")
    print("=" * 45)

    baseline_model = Pipeline([
        ("tfidf", TfidfVectorizer(
            stop_words="english",
            ngram_range=(1, 2),
            max_features=100000,
            min_df=2
        )),
        ("classifier", LogisticRegression(
            max_iter=1000,
            class_weight="balanced"
        ))
    ])

    print("\nTraining claim-only classifier...")
    baseline_model.fit(X_train_claims, y_train)

    baseline_predictions = baseline_model.predict(X_test_claims)

    print("\nClaim-only evaluation")
    print("-" * 40)

    print(
        "Accuracy:",
        round(accuracy_score(y_test, baseline_predictions), 4)
    )

    print(
        classification_report(
            y_test,
            baseline_predictions,
            zero_division=0
        )
    )



if __name__ == "__main__":
    main()
