
import json
import re
from pathlib import Path

import numpy as np
from rank_bm25 import BM25Okapi
from sentence_transformers import SentenceTransformer


PROJECT_ROOT = Path(__file__).resolve().parent.parent
CHUNKS_FILE = PROJECT_ROOT / "data" / "evidence_chunks.jsonl"
EMBEDDINGS_FILE = PROJECT_ROOT / "data" / "semantic_embeddings.npy"
TEST_CLAIMS_FILE = Path(__file__).with_name("test_claim.txt")

MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"
TOP_K = 3


def tokenize(text):
    return re.findall(r"\b\w+\b", text.lower())


class HybridRetriever:

    def __init__(self):

        print("Loading evidence chunks...")

        self.chunks = []

        with open(CHUNKS_FILE, "r", encoding="utf-8") as file:
            for line in file:
                if line.strip():
                    self.chunks.append(json.loads(line))

        print("Loading semantic embeddings...")

        self.embeddings = np.load(EMBEDDINGS_FILE)

        if len(self.chunks) != len(self.embeddings):
            raise ValueError("Chunk count does not match embedding count.")

        print("Building BM25 index...")

        tokenized_chunks = [
            tokenize(chunk.get("text", ""))
            for chunk in self.chunks
        ]

        self.bm25 = BM25Okapi(tokenized_chunks)

        print("Loading semantic model...")

        self.model = SentenceTransformer(MODEL_NAME)

        print("Hybrid retriever ready!")

    def reciprocal_rank_fusion(
        self, bm25_scores, semantic_scores, k=60
    ):

        bm25_ranking = np.argsort(bm25_scores)[::-1]
        semantic_ranking = np.argsort(semantic_scores)[::-1]

        rrf_scores = np.zeros(len(bm25_scores))

        for rank, index in enumerate(bm25_ranking, start=1):
            rrf_scores[index] += 1 / (k + rank)

        for rank, index in enumerate(semantic_ranking, start=1):
            rrf_scores[index] += 1 / (k + rank)

        return rrf_scores

    def retrieve(self, claim, top_k=TOP_K):

        bm25_scores = self.bm25.get_scores(tokenize(claim))

        claim_embedding = self.model.encode(
            [claim],
            normalize_embeddings=True
        )[0]

        semantic_scores = self.embeddings @ claim_embedding

        hybrid_scores = self.reciprocal_rank_fusion(
            bm25_scores,
            semantic_scores
        )

        ranked_indices = np.argsort(hybrid_scores)[::-1][:top_k]

        results = []

        for index in ranked_indices:
            results.append({
                "title": self.chunks[index]["title"],
                "chunk_id": self.chunks[index]["chunk_id"],
                "text": self.chunks[index]["text"],
                "score": float(hybrid_scores[index])
            })

        return results


def main():

    if not TEST_CLAIMS_FILE.exists():
        print("Test claims file not found:", TEST_CLAIMS_FILE)
        return

    retriever = HybridRetriever()

    with open(TEST_CLAIMS_FILE, "r", encoding="utf-8") as file:
        claims = [
            line.strip()
            for line in file
            if line.strip()
        ]

    for claim_number, claim in enumerate(claims, start=1):

        results = retriever.retrieve(claim)

        print("\n" + "=" * 70)
        print(f"CLAIM {claim_number}: {claim}")
        print("Top 3 evidence passages")
        print("=" * 70)

        for rank, result in enumerate(results, start=1):
            print(f"\n{rank}. RRF score: {result['score']:.6f}")
            print("Page:", result["title"])
            print("Evidence:", result["text"])
            print("-" * 60)


if __name__ == "__main__":
    main()
