import json
import re
from pathlib import Path

PROJECT_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = PROJECT_DIR / "data"
PAGES_FILE = DATA_DIR / "all_required_wiki_pages.jsonl"
OUTPUT_FILE = DATA_DIR / "structured_extraction_preview.jsonl"

TARGET_PAGES = {"Chemical Chords", "Mario Party", "Besa Tsintsadze"}


def clean_text(text):
    """Remove Wikipedia link markup while keeping the displayed text."""
    text = re.sub(r"\[\[([^|\]]+)\|([^\]]+)\]\]", r"\2", text)
    text = re.sub(r"\[\[([^\]]+)\]\]", r"\1", text)
    return re.sub(r"\s+", " ", text).strip()


def cell_text(cell):
    if isinstance(cell, str):
        return clean_text(cell)
    if isinstance(cell, dict):
        value = cell.get("value")
        if isinstance(value, str):
            return clean_text(value)
        if value is not None:
            return collect_text(value)
    return collect_text(cell)


def collect_text(value):
    """Collect readable text from nested FEVEROUS values."""
    parts = []
    if isinstance(value, str):
        text = clean_text(value)
        if text:
            parts.append(text)
    elif isinstance(value, dict):
        if "value" in value:
            parts.extend(collect_text(value["value"]))
        else:
            for key, item in value.items():
                if key not in {"id", "is_header", "column_span", "row_span"}:
                    parts.extend(collect_text(item))
    elif isinstance(value, list):
        for item in value:
            parts.extend(collect_text(item))
    return parts


def find_cell_rows(value):
    """Find nested table rows containing cell-like dictionaries."""
    found = []
    if isinstance(value, dict):
        for item in value.values():
            found.extend(find_cell_rows(item))
    elif isinstance(value, list):
        # A row is usually a list whose entries are cell dictionaries.
        if value and all(
            isinstance(item, dict) and ("value" in item or "id" in item)
            for item in value
        ):
            found.append(value)
        else:
            for item in value:
                found.extend(find_cell_rows(item))
    return found


def get_cell_info(cell):
    if isinstance(cell, dict):
        return {
            "id": cell.get("id"),
            "text": cell_text(cell),
            "is_header": bool(cell.get("is_header", False)),
            "row_span": cell.get("row_span"),
            "column_span": cell.get("column_span"),
        }
    return {
        "id": None,
        "text": cell_text(cell),
        "is_header": False,
        "row_span": None,
        "column_span": None,
    }


def ordered_element_keys(page):
    """Use page order when available; otherwise retain JSON key order."""
    element_keys = [
        key for key in page
        if key.startswith(("sentence_", "table_", "list_"))
    ]
    order = page.get("order")
    if not isinstance(order, list):
        return element_keys

    ordered = []
    for item in order:
        candidate = item if isinstance(item, str) else None
        if candidate in page and candidate in element_keys and candidate not in ordered:
            ordered.append(candidate)
            continue
        # Some page versions store element IDs rather than dictionary keys.
        if candidate:
            for key in element_keys:
                obj = page.get(key)
                ids = [x for x in collect_ids(obj)]
                if candidate in ids and key not in ordered:
                    ordered.append(key)
                    break
    ordered.extend(key for key in element_keys if key not in ordered)
    return ordered


def collect_ids(value):
    if isinstance(value, dict):
        if isinstance(value.get("id"), str):
            yield value["id"]
        for item in value.values():
            yield from collect_ids(item)
    elif isinstance(value, list):
        for item in value:
            yield from collect_ids(item)


def extract_element(page, key, section_context):
    value = page[key]
    element_type = key.split("_", 1)[0]
    base = {
        "element_key": key,
        "element_type": element_type,
        "section_context": section_context,
    }

    if element_type == "table":
        rows = []
        for row_index, raw_row in enumerate(find_cell_rows(value)):
            cells = [get_cell_info(cell) for cell in raw_row]
            if not any(cell["text"] for cell in cells):
                continue
            rows.append({"row_index": row_index, "cells": cells})

        caption_parts = []
        if isinstance(value, dict):
            for field in ("table_caption", "caption", "title"):
                if field in value:
                    caption_parts.extend(collect_text(value[field]))
        base.update({
            "table_caption": " ".join(caption_parts),
            "rows": rows,
        })
        return base

    base["text"] = " ".join(collect_text(value))
    base["ids"] = list(dict.fromkeys(collect_ids(value)))
    return base


def extract_page(page):
    title = page.get("title", "UNKNOWN_TITLE")
    elements = []
    current_section = ""

    for key in ordered_element_keys(page):
        value = page[key]
        if key.startswith("sentence_"):
            text = " ".join(collect_text(value))
            # Section headings are often represented by section metadata. Keep
            # the current context if the page schema supplies it separately.
            if text and ("section" in key.lower()):
                current_section = text
        element = extract_element(page, key, current_section)
        if element.get("text") or element.get("rows"):
            elements.append(element)

    return {"title": title, "elements": elements}


def main():
    if not PAGES_FILE.exists():
        raise FileNotFoundError(f"Pages file not found: {PAGES_FILE}")

    found = set()
    output_count = 0
    with PAGES_FILE.open("r", encoding="utf-8") as source, OUTPUT_FILE.open(
        "w", encoding="utf-8"
    ) as output:
        for line in source:
            line = line.strip()
            if not line:
                continue
            page = json.loads(line)
            title = page.get("title")
            if title not in TARGET_PAGES:
                continue
            result = extract_page(page)
            output.write(json.dumps(result, ensure_ascii=False) + "\n")
            found.add(title)
            output_count += 1
            if found == TARGET_PAGES:
                break

    missing = sorted(TARGET_PAGES - found)
    print(f"Structured extraction complete. Pages found: {output_count}/3")
    print(f"Preview saved to: {OUTPUT_FILE}")
    if missing:
        print("Pages not found: " + ", ".join(missing))


if __name__ == "__main__":
    main()
