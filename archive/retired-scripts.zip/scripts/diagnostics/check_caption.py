import json
from pathlib import Path

PROJECT_DIR = Path(__file__).resolve().parents[2]
PAGES_FILE = PROJECT_DIR / "data" / "all_required_wiki_pages.jsonl"

target = "2006–07 San Jose Sharks season"


def search_captions(obj, path="page"):
    if isinstance(obj, dict):
        for key, value in obj.items():
            if "caption" in str(key).lower():
                print("\nFOUND:")
                print("Path:", path + "." + str(key))
                print("Value:", repr(value))

            search_captions(value, path + "." + str(key))

    elif isinstance(obj, list):
        for index, value in enumerate(obj):
            search_captions(value, path + f"[{index}]")


with open(PAGES_FILE, "r", encoding="utf-8") as file:
    for line in file:
        page = json.loads(line)

        if page.get("title") == target:
            print("Searching entire page:", target)
            search_captions(page)
            break