
import json
import re
import unicodedata
from collections import Counter, defaultdict
from pathlib import Path

PROJECT_DIR = Path(__file__).resolve().parents[2]
DATA_DIR = PROJECT_DIR / "data"

TRAIN_FILE = DATA_DIR / "clean_train.jsonl"
LOOKUP_FILE = DATA_DIR / "evidence_lookup_full.json"


def normalize(text):
    return unicodedata.normalize("NFC", text)


def identify_type(evidence_id):
    patterns = [
        (r"_table_caption_\d+$", "table_caption"),
        (r"_header_cell_\d+_\d+_\d+$", "header_cell"),
        (r"_cell_\d+_\d+_\d+$", "table_cell"),
        (r"_sentence_\d+$", "sentence"),
        (r"_item_\d+$", "item"),
        (r"_section_\d+$", "section"),
    ]

    for pattern, label in patterns:
        if re.search(pattern, evidence_id):
            return label

    return "other"


def main():
    with open(LOOKUP_FILE, "r", encoding="utf-8") as file:
        lookup = json.load(file)

    missing = Counter()
    examples = defaultdict(list)

    with open(TRAIN_FILE, "r", encoding="utf-8") as file:
        for line in file:
            if not line.strip():
                continue

            record = json.loads(line)

            for group in record.get("evidence", []):
                for evidence_id in group.get("content", []):
                    normalized_id = normalize(evidence_id)

                    if normalized_id not in lookup:
                        evidence_type = identify_type(normalized_id)
                        missing[evidence_type] += 1

                        if len(examples[evidence_type]) < 10:
                            examples[evidence_type].append(normalized_id)

    print("\nMISSING EVIDENCE BY TYPE")
    print("-" * 40)

    for evidence_type, count in missing.most_common():
        print(f"\n{evidence_type}: {count}")

        for example in examples[evidence_type]:
            print("  ", example)

    print("\nTOTAL MISSING REFERENCES:", sum(missing.values()))


if __name__ == "__main__":
    main()
