import json
from pathlib import Path

# File paths
INPUT_FILE = Path(__file__).resolve().parents[2] / "data" / "structured_extraction_preview_v2.jsonl"
OUTPUT_FILE = Path(__file__).resolve().parents[2] / "data" / "sample_check.txt"

# Pages to inspect
TARGET_PAGES = {
    "Besa Tsintsadze",
    "Mario Party"
}


def main():
    if not INPUT_FILE.exists():
        print(f"Error: Input file not found: {INPUT_FILE}")
        return

    total_records = 0
    matched_records = 0

    with INPUT_FILE.open("r", encoding="utf-8") as infile:
        with OUTPUT_FILE.open("w", encoding="utf-8") as outfile:

            outfile.write("STRUCTURED EXTRACTION SAMPLE CHECK\n")
            outfile.write("=" * 50 + "\n")

            for line_number, line in enumerate(infile, start=1):

                if not line.strip():
                    continue

                try:
                    record = json.loads(line)
                except json.JSONDecodeError as error:
                    print(f"Invalid JSON on line {line_number}: {error}")
                    continue

                total_records += 1

                page_title = record.get("page_title", "")

                if page_title not in TARGET_PAGES:
                    continue

                matched_records += 1

                outfile.write("\n" + "=" * 50 + "\n")
                outfile.write(f"PAGE: {page_title}\n")
                outfile.write(f"RECORD TYPE: {record.get('record_type', 'Unknown')}\n")
                outfile.write("=" * 50 + "\n")

                outfile.write(
                    json.dumps(
                        record,
                        indent=2,
                        ensure_ascii=False
                    )
                )

                outfile.write("\n")

            outfile.write("\n" + "=" * 50 + "\n")
            outfile.write("SUMMARY\n")
            outfile.write("=" * 50 + "\n")
            outfile.write(f"Total records scanned: {total_records}\n")
            outfile.write(f"Matching records: {matched_records}\n")

    print("Inspection complete.")
    print(f"Total records scanned: {total_records}")
    print(f"Matching records: {matched_records}")
    print(f"Output saved to: {OUTPUT_FILE.resolve()}")


if __name__ == "__main__":
    main()