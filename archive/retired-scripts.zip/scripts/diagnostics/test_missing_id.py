import json
import unicodedata
from pathlib import Path

PROJECT_DIR = Path(__file__).resolve().parents[2]

LOOKUP_FILE = PROJECT_DIR / "data" / "evidence_lookup_full.json"

with open(LOOKUP_FILE, "r", encoding="utf-8") as file:
    lookup = json.load(file)

test_id = "Aukštaitian dialect_cell_0_3_1"

normalized_id = unicodedata.normalize("NFC", test_id)

print("Original ID found:", test_id in lookup)
print("Normalized ID found:", normalized_id in lookup)
print("Original ID:", repr(test_id))
print("Normalized ID:", repr(normalized_id))