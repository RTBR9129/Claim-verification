import json
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
INPUT_FILE = ROOT / "data" / "structured_extraction_preview.jsonl"
REPORT_FILE = ROOT / "data" / "preview_inspection.txt"

type_counts = Counter()
samples = []

with INPUT_FILE.open("r", encoding="utf-8") as file:
    for line in file:
        if not line.strip():
            continue

        record = json.loads(line)

        type_counts[record.get("record_type", "MISSING")] += 1

        if len(samples) < 5:
            samples.append(record)

with REPORT_FILE.open("w", encoding="utf-8") as file:
    file.write("RECORD TYPE COUNTS\n")
    file.write("==================\n")

    for record_type, count in type_counts.items():
        file.write(f"{record_type}: {count}\n")

    file.write("\nSAMPLE RECORDS\n")
    file.write("==============\n")

    for record in samples:
        file.write(json.dumps(record, indent=2, ensure_ascii=False))
        file.write("\n\n")

print("Inspection complete.")
print(f"Report saved to: {REPORT_FILE}")