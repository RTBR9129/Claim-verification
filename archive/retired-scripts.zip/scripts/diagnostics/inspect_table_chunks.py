
import json
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]
CHUNKS_FILE = PROJECT_ROOT / "data" / "evidence_chunks.jsonl"

SEARCH_TERMS = [
    "Mario Party",
    "Besa Tsintsadze",
    "Chemical Chords"
]

def main():
    found = {term: 0 for term in SEARCH_TERMS}

    with CHUNKS_FILE.open("r", encoding="utf-8") as file:
        for line in file:
            chunk = json.loads(line)
            text = str(chunk.get("text", ""))

            for term in SEARCH_TERMS:
                if term.lower() in text.lower() and found[term] < 3:
                    found[term] += 1
                    print("\n" + "=" * 90)
                    print("SEARCH:", term)
                    print(json.dumps(chunk, ensure_ascii=False, indent=2))

    print("\nChunks found:")
    for term, count in found.items():
        print(f"{term}: {count}")


if __name__ == "__main__":
    main()
