
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

INPUT_FILE = ROOT / "data" / "structured_extraction_preview.jsonl"
OUTPUT_FILE = ROOT / "data" / "structured_extraction_preview_v2.jsonl"
REPORT_FILE = ROOT / "data" / "structured_preview_check.txt"


def get_cell_text(cell):
    return str(cell.get("text", "")).strip()


def process_table(page_title, element):
    rows = element.get("rows", [])
    table_key = element.get("element_key", "unknown_table")

    # Find the actual column headings.
    column_headers = {}

    for row in rows:
        cells = row.get("cells", [])

        if cells and all(cell.get("is_header") for cell in cells):
            if len(cells) > 1:
                for index, cell in enumerate(cells):
                    column_headers[index] = get_cell_text(cell)
                break

    output = []

    for row in rows:
        cells = row.get("cells", [])
        if not cells:
            continue

        texts = [get_cell_text(cell) for cell in cells]

        # Ignore completely empty rows.
        if not any(texts):
            continue

        # Skip the column-heading row.
        if column_headers and all(
            cell.get("is_header") for cell in cells
        ):
            continue

        # Ignore section-title rows, but preserve them as context.
        if len(cells) == 1 and cells[0].get("is_header"):
            continue

        evidence_ids = [
            cell.get("id")
            for cell in cells
            if cell.get("id")
        ]

        # Two-column key-value / infobox row.
        if len(cells) == 2 and cells[0].get("is_header"):
            field = texts[0]
            value = texts[1]

            record = {
                "record_type": "table_row",
                "page_title": page_title,
                "table_key": table_key,
                "table_caption": element.get("table_caption", ""),
                "section_context": element.get("section_context", ""),
                "field": field,
                "value": value,
                "text": f"{field}: {value}",
                "evidence_ids": evidence_ids
            }

        else:
            # Wider table: first cell is the row label.
            row_label = texts[0]
            values = {}

            for index, cell_text in enumerate(texts[1:], start=1):
                if index in column_headers:
                    column_name = column_headers[index]
                else:
                    column_name = f"column_{index + 1}"

                values[column_name] = cell_text

            parts = [f"Row: {row_label}"]

            for key, value in values.items():
                parts.append(f"{key}: {value}")

            record = {
                "record_type": "table_row",
                "page_title": page_title,
                "table_key": table_key,
                "table_caption": element.get("table_caption", ""),
                "section_context": element.get("section_context", ""),
                "row_label": row_label,
                "values": values,
                "text": " | ".join(parts),
                "evidence_ids": evidence_ids
            }

        output.append(record)

    return output


def main():
    if not INPUT_FILE.exists():
        raise FileNotFoundError(INPUT_FILE)

    records = []

    with INPUT_FILE.open("r", encoding="utf-8") as file:
        for line in file:
            if not line.strip():
                continue

            page = json.loads(line)
            page_title = page.get("title", "")

            for element in page.get("elements", []):
                element_type = element.get("element_type")
                element_key = element.get("element_key", "")

                if element_type == "table":
                    records.extend(
                        process_table(page_title, element)
                    )

                elif element_type in ("sentence", "list"):
                    records.append({
                        "record_type": element_type,
                        "page_title": page_title,
                        "element_key": element_key,
                        "section_context": element.get(
                            "section_context", ""
                        ),
                        "text": element.get("text", ""),
                        "evidence_ids": element.get("ids", [])
                    })

    with OUTPUT_FILE.open("w", encoding="utf-8") as file:
        for record in records:
            file.write(
                json.dumps(record, ensure_ascii=False) + "\n"
            )

    table_count = sum(
        1 for r in records
        if r["record_type"] == "table_row"
    )

    sentence_count = sum(
        1 for r in records
        if r["record_type"] == "sentence"
    )

    list_count = sum(
        1 for r in records
        if r["record_type"] == "list"
    )

    with REPORT_FILE.open("w", encoding="utf-8") as file:
        file.write("STRUCTURED PREVIEW V2 CHECK\n")
        file.write("===========================\n\n")
        file.write(f"Total records: {len(records)}\n")
        file.write(f"Table rows: {table_count}\n")
        file.write(f"Sentences: {sentence_count}\n")
        file.write(f"Lists: {list_count}\n\n")

        file.write("SAMPLE TABLE ROWS\n")
        file.write("=================\n")

        samples = [
            r for r in records
            if r["record_type"] == "table_row"
        ]

        for sample in samples[:10]:
            file.write(
                json.dumps(sample, ensure_ascii=False) + "\n"
            )

    print("Extraction formatting complete.")
    print(f"Total records: {len(records)}")
    print(f"Table rows: {table_count}")
    print(f"Output: {OUTPUT_FILE}")
    print(f"Report: {REPORT_FILE}")


if __name__ == "__main__":
    main()
