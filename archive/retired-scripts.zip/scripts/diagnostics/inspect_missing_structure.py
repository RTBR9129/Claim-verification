
import json
import unicodedata
from pathlib import Path

PROJECT_DIR = Path(__file__).resolve().parents[2]
DATA_DIR = PROJECT_DIR / "data"

PAGES_FILE = DATA_DIR / "all_required_wiki_pages.jsonl"

targets = {
    "2006–07 San Jose Sharks season": [
        "table_caption_1"
    ],
    "Hunar Hali": [
        "cell_1_1_2"
    ],
    "Marrecs de Salt": [
        "header_cell_4_0_0"
    ]
}


def normalize(text):
    return unicodedata.normalize("NFC", text)


def inspect_object(obj, target_ids, path=""):
    if isinstance(obj, dict):
        if obj.get("id") in target_ids:
            print("\nMATCH FOUND")
            print("Path:", path)
            print(json.dumps(obj, ensure_ascii=False, indent=2))

        for key, value in obj.items():
            inspect_object(value, target_ids, f"{path}/{key}")

    elif isinstance(obj, list):
        for index, value in enumerate(obj):
            inspect_object(value, target_ids, f"{path}/{index}")


with open(PAGES_FILE, "r", encoding="utf-8") as file:
    for line in file:
        if not line.strip():
            continue

        page = json.loads(line)
        title = normalize(page.get("title", ""))

        if title not in targets:
            continue

        print("\n" + "=" * 60)
        print("PAGE:", title)
        print("TOP-LEVEL KEYS:", list(page.keys()))

        target_ids = set(targets[title])

        inspect_object(page, target_ids)

        for key, value in page.items():
            if key.startswith("table_"):
                print("\nTABLE STRUCTURE:", key)

                if isinstance(value, dict):
                    print("TABLE KEYS:", list(value.keys()))
                    print(
                        json.dumps(value, ensure_ascii=False, indent=2)[:5000]
                    )
