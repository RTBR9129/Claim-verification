
import json
from pathlib import Path

DATA_DIR = Path(__file__).resolve().parents[2] / "data"

file_path = DATA_DIR / "selected_wiki_pages.jsonl"

with open(file_path, "r", encoding="utf-8") as file:
    for line in file:
        page = json.loads(line)
        print(page.get("title", "Unknown"))
