
import json
import unicodedata
from pathlib import Path

PROJECT_DIR = Path(__file__).resolve().parents[2]
PAGES_FILE = PROJECT_DIR / "data" / "all_required_wiki_pages.jsonl"

targets = {
    "2006–07 San Jose Sharks season": [
        "table_caption_1"
    ],
    "Hunar Hali": [
        "cell_1_1_2"
    ],
    "Marrecs de Salt": [
        "header_cell_4_0_0"
    ]
}

def normalize(text):
    return unicodedata.normalize("NFC", text)


def find_id(obj, target_ids):
    if isinstance(obj, dict):
        if obj.get("id") in target_ids:
            print("MATCH:", obj)

        for value in obj.values():
            find_id(value, target_ids)

    elif isinstance(obj, list):
        for value in obj:
            find_id(value, target_ids)


with open(PAGES_FILE, "r", encoding="utf-8") as file:
    for line in file:
        page = json.loads(line)
        title = normalize(page.get("title", ""))

        if title not in targets:
            continue

        print("\n" + "=" * 50)
        print("PAGE:", title)

        for key in page:
            if key in targets[title]:
                print("CAPTION:", key, "=", repr(page[key]))

        find_id(page, set(targets[title]))
