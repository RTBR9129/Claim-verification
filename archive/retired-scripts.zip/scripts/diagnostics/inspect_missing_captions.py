from pathlib import Path
import unicodedata

PROJECT_DIR = Path(__file__).resolve().parents[2]
TITLES_FILE = PROJECT_DIR / "data" / "all_required_titles.txt"

targets = [
    "Long Island Lutheran Middle and High School",
    "Eric Walter Elst",
    "FK Slavija Sarajevo",
    "NK Čelik Zenica",
    "1979 Horsham District Council election",
    "1904 Pembrokeshire County Council election",
    "1977 IAAF World Cross Country Championships",
    "United States Senate Committee on the Judiciary"
]

def normalize(text):
    return unicodedata.normalize("NFC", text).strip()

with open(TITLES_FILE, "r", encoding="utf-8") as file:
    titles = {normalize(line) for line in file if line.strip()}

print("REQUIRED TITLE CHECK")
print("-" * 40)

for target in targets:
    if normalize(target) in titles:
        print("FOUND:", target)
    else:
        print("NOT FOUND:", target)