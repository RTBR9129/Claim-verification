
import json
from pathlib import Path

PROJECT_DIR = Path(__file__).resolve().parents[2]
DATA_DIR = PROJECT_DIR / "data"

INPUT_FILE = DATA_DIR / "all_required_wiki_pages.jsonl"
OUTPUT_FILE = DATA_DIR / "page_structure_inspection.txt"

TARGETS = [
    "Chemical Chords",
    "Mario Party",
    "Besa Tsintsadze"
]


def main():
    found = set()

    with open(INPUT_FILE, "r", encoding="utf-8") as source, \
         open(OUTPUT_FILE, "w", encoding="utf-8") as output:

        for line in source:
            if not line.strip():
                continue

            page = json.loads(line)
            title = page.get("title", "")

            if title not in TARGETS:
                continue

            found.add(title)

            output.write("\n" + "=" * 80 + "\n")
            output.write(f"PAGE: {title}\n")
            output.write("=" * 80 + "\n")

            output.write(
                json.dumps(page, indent=2, ensure_ascii=False)
            )
            output.write("\n")

    print("Inspection complete.")
    print("Pages found:", len(found), "/", len(TARGETS))
    print("Found:", ", ".join(sorted(found)))
    print("Full output saved to:", OUTPUT_FILE)


if __name__ == "__main__":
    main()
