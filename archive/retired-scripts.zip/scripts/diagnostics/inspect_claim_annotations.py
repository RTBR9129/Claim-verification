
import json
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]
TRAIN_FILE = PROJECT_ROOT / "data" / "clean_train.jsonl"
LOOKUP_FILE = PROJECT_ROOT / "data" / "evidence_lookup_full.json"

TARGETS = [
    "Summer Games Tennis Tournament, Chung Hyeon ranked first",
    "The Toad character appeared in more Mario Party",
    "Chemical Chords received a rating of 7/10 from Uncut",
    "Besa Tsintsadze competed in the World Championships",
]

MAX_MATCHES_PER_TARGET = 5
MAX_EVIDENCE_IDS = 30


def load_lookup(path):
    print("\nLoading evidence lookup...")
    with path.open("r", encoding="utf-8") as file:
        lookup = json.load(file)

    print("Lookup top-level type:", type(lookup).__name__)

    if isinstance(lookup, dict):
        print("Lookup entries:", len(lookup))
        sample_key = next(iter(lookup), None)
        if sample_key is not None:
            print("Sample lookup key:", sample_key)
            print("Sample lookup value:")
            print(json.dumps(lookup[sample_key], ensure_ascii=False, indent=2)[:1500])
    elif isinstance(lookup, list):
        print("Lookup entries:", len(lookup))
        if lookup:
            print("Sample lookup item:")
            print(json.dumps(lookup[0], ensure_ascii=False, indent=2)[:1500])

    return lookup


def get_lookup_item(lookup, evidence_id):
    if isinstance(lookup, dict):
        item = lookup.get(evidence_id)
        if item is not None:
            return item

        for value in lookup.values():
            if isinstance(value, dict):
                item_id = value.get("id") or value.get("evidence_id")
                if item_id == evidence_id:
                    return value

    elif isinstance(lookup, list):
        for item in lookup:
            if isinstance(item, dict):
                item_id = item.get("id") or item.get("evidence_id")
                if item_id == evidence_id:
                    return item

    return None


def print_lookup_record(lookup, evidence_id, prefix=""):
    item = get_lookup_item(lookup, evidence_id)
    print(f"\n{prefix}{evidence_id}")

    if item is None:
        print("  [NOT FOUND in evidence lookup]")
        return

    if isinstance(item, str):
        print("  ", item)
    else:
        rendered = json.dumps(item, ensure_ascii=False, indent=2)
        print(rendered[:2500])
        if len(rendered) > 2500:
            print("  ... [record truncated]")


def inspect_claim(record, lookup):
    print("\n" + "=" * 100)
    print("CLAIM:", record.get("claim", ""))
    print("LABEL:", record.get("label", "UNKNOWN"))

    groups = record.get("evidence", [])

    if not groups:
        print("\nAVAILABLE RECORD FIELDS:")
        print(list(record.keys()))

        print("\nCOMPLETE RECORD:")
        print(json.dumps(record, ensure_ascii=False, indent=2)[:10000])

        print("\nNo evidence_groups field found.")
        return

    for group_number, group in enumerate(groups, start=1):
        print(f"\n--- Evidence group {group_number} ---")

        content_ids = group.get("content", [])
        context_map = group.get("context", {})

        print("Evidence IDs:", len(content_ids))
        print("Context entries:", len(context_map))

        for evidence_id in content_ids[:MAX_EVIDENCE_IDS]:
            print_lookup_record(lookup, evidence_id, prefix="EVIDENCE: ")

            for context_id in context_map.get(evidence_id, []):
                print_lookup_record(
                    lookup, context_id, prefix="    CONTEXT: "
                )

        if len(content_ids) > MAX_EVIDENCE_IDS:
            print(
                f"Only first {MAX_EVIDENCE_IDS} IDs printed "
                f"out of {len(content_ids)}."
            )


def main():
    if not TRAIN_FILE.exists():
        raise FileNotFoundError(f"Training file not found: {TRAIN_FILE}")

    if not LOOKUP_FILE.exists():
        raise FileNotFoundError(f"Evidence lookup not found: {LOOKUP_FILE}")

    lookup = load_lookup(LOOKUP_FILE)
    matches = {target: [] for target in TARGETS}

    print("\nReading training claims...")
    with TRAIN_FILE.open("r", encoding="utf-8") as file:
        for line in file:
            if not line.strip():
                continue

            record = json.loads(line)
            claim = record.get("claim", "")

            for target in TARGETS:
                if (
                    target.lower() in claim.lower()
                    and len(matches[target]) < MAX_MATCHES_PER_TARGET
                ):
                    matches[target].append(record)

    for target, records in matches.items():
        print("\n\n" + "#" * 100)
        print("SEARCH TARGET:", target)
        print("MATCHES FOUND:", len(records))

        if not records:
            print("No matching claims found.")

        for record in records:
            inspect_claim(record, lookup)


if __name__ == "__main__":
    main()
