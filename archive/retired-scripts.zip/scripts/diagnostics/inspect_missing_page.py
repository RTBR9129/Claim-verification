import json
import unicodedata
from pathlib import Path

PROJECT_DIR = Path(__file__).resolve().parents[2]
PAGES_FILE = PROJECT_DIR / "data" / "all_required_wiki_pages.jsonl"

target = unicodedata.normalize("NFC", "Aukštaitian dialect")

with open(PAGES_FILE, "r", encoding="utf-8") as file:
    for line in file:
        page = json.loads(line)

        title = unicodedata.normalize(
            "NFC", page.get("title", "")
        )

        if title == target:
            print("PAGE FOUND:", repr(page["title"]))

            for key, value in page.items():
                if key.startswith("table_"):
                    print("\nTABLE:", key)
                    print(json.dumps(
                        value,
                        ensure_ascii=False,
                        indent=2
                    )[:6000])

            break
    else:
        print("PAGE NOT FOUND")